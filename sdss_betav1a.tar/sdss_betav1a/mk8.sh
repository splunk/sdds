#!/bin/bash
microk8s enable dns
microk8s enable storage
microk8s enable metallb
microk8s enable istio
